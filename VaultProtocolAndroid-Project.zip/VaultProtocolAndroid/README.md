# The Vault Protocol for Android

This project wraps the hardened Vault Protocol HTML in an Android WebView. It uses app-owned WebView storage (LocalStorage and IndexedDB), and Android's system file picker for JSON/JSONL export and JSON restore.

## Build an APK using only your phone (GitHub Actions)

You do not need a PC. GitHub builds the APK on its servers. These steps require a free GitHub account.

1. Download and extract `VaultProtocolAndroid-Project.zip` on your phone.
2. In Chrome, open https://github.com/new and create a **private** repository, for example `vault-protocol-android`. Do not add a README or other files during creation.
3. Open the new repository's **Add file → Upload files** page. Upload the contents of the extracted `VaultProtocolAndroid` folder, including the hidden `.github` folder and its `workflows/build-apk.yml` file. If the phone's file picker hides dot-folders or makes uploading many files difficult, use GitHub's browser-based file upload for the files and make sure the workflow file is included.
4. Commit the uploaded files to the `main` branch.
5. In the repository, open **Actions**. If GitHub asks to enable workflows, enable them. Select **Build Vault Protocol APK** and tap **Run workflow** if it has not already started.
6. Open the completed run and scroll to **Artifacts**. Download `Vault-Protocol-debug-APK`, then extract the ZIP to get `app-debug.apk`.
7. Tap `app-debug.apk` in Downloads to install. Android may ask you to allow your browser or file manager to install unknown apps. Only enable this for the app you used to download the APK, and turn it back off afterward if you prefer.

GitHub's menu labels can vary slightly on mobile. The build artifact is temporary and expires after 14 days, so download it when the workflow finishes.

## Build details and limitations

- The workflow uses GitHub-hosted Ubuntu, Java 17, Gradle 8.9, and Android Gradle Plugin 8.7.3.
- This produces a **debug APK**, suitable for personal installation, not a signed Play Store release.
- The APK has not yet been built or tested on a physical device from this environment. The workflow will report compilation errors if any occur.
- The HTML references Tailwind, Lucide, and Google Fonts from CDNs, so some visual styling may be reduced without internet access. App data is stored locally.
- App-private storage is separate from Chrome, but uninstalling the app can erase its private data. Export backups regularly.
- Keep the GitHub repository private if you do not want the app's source publicly visible. Do not upload passwords, API keys, or personal records to the repository.
